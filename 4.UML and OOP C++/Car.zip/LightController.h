#pragma once
class LightController
{

};

