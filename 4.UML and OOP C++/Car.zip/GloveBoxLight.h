#pragma once
#include "CeilingLights.h"
class GloveBoxLight :
    public CeilingLights
{
protected:
    virtual void printStatus();
};

