#include "GloveBoxLight.h"
#include <iostream>

void GloveBoxLight::printStatus()
{
	std::cout << "The Glovebox Light is " << convertStatusToString() << std::endl;
}

